import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import minimize


def model(theta_deg: float, M: float, X: float, t: np.ndarray):
    theta = np.deg2rad(theta_deg)
    abs_t = np.abs(t)
    exp_term = np.exp(M * abs_t)
    x = t * np.cos(theta) - exp_term * np.sin(0.3 * t) * np.sin(theta) + X
    y = 42 + t * np.sin(theta) + exp_term * np.sin(0.3 * t) * np.cos(theta)
    return x, y



def l1_error(params: np.ndarray, t: np.ndarray, x_obs: np.ndarray, y_obs: np.ndarray) -> float:
    theta_deg, M, X = params
    x_pred, y_pred = model(theta_deg, M, X, t)


    return float(np.sum(np.abs(x_pred - x_obs) + np.abs(y_pred - y_obs)))


def main():
    csv_path = "xy_data.csv"
    df = pd.read_csv(csv_path)

    if not {"x", "y"}.issubset(df.columns):
        raise ValueError("CSV must contain columns named 'x' and 'y'.")

    x_obs = df["x"].to_numpy(dtype=float)
    y_obs = df["y"].to_numpy(dtype=float)

    n = len(df)
    t = np.linspace(6.0, 60.0, n, dtype=float)

    theta_bounds = (0.0, 50.0)
    M_bounds = (-0.05, 0.05)
    X_bounds = (0.0, 100.0)


    theta_grid = np.linspace(theta_bounds[0], theta_bounds[1], 45)  
    M_grid = np.linspace(M_bounds[0], M_bounds[1], 31)   

   
    def best_X_l1(base_x: np.ndarray):
        residual = x_obs - base_x
        return float(np.median(residual))

    best_params = None
    best_err = np.inf

    for theta_deg in theta_grid:
        theta = np.deg2rad(theta_deg)
        abs_t = np.abs(t)

        for M in M_grid:
            abs_t = np.abs(t)
            exp_term = np.exp(M * abs_t)
            base_x = t * np.cos(theta) - exp_term * np.sin(0.3 * t) * np.sin(theta)

            X0 = best_X_l1(base_x)
            x_pred, y_pred = model(theta_deg, M, X0, t)
            X0 = float(np.clip(X0, X_bounds[0], X_bounds[1]))
            x_pred, y_pred = model(theta_deg, M, X0, t)
            err = float(np.sum(np.abs(x_pred - x_obs) + np.abs(y_pred - y_obs)))
            if err < best_err:
                best_err = err
                best_params = np.array([theta_deg, M, X0], dtype=float)


  
    def huber(z, delta=1.0):
        az = np.abs(z)
        return np.where(az <= delta, 0.5 * az * az / delta, az - 0.5 * delta)

    def objective(params):
        theta_deg, M, X = params

        if not (theta_bounds[0] <= theta_deg <= theta_bounds[1]):
            return 1e12
        if not (M_bounds[0] <= M <= M_bounds[1]):
            return 1e12
        x_pred, y_pred = model(theta_deg, M, X, t)
        dx = x_pred - x_obs
        dy = y_pred - y_obs
        return float(np.sum(huber(dx, delta=0.5) + huber(dy, delta=0.5)))

    theta0, M0, X0 = best_params
    x_opt = minimize(
        objective,
        x0=np.array([theta0, M0, X0], dtype=float),
        method="Powell",
        options={"maxiter": 4000, "disp": False},
    )

    theta_opt, M_opt, X_opt = x_opt.x

    final_l1 = l1_error(x_opt.x, t, x_obs, y_obs)
    x_pred, y_pred = model(theta_opt, M_opt, X_opt, t)

    print("Estimated parameters")
    print(f"theta (deg): {theta_opt:.6f}")
    print(f"M        : {M_opt:.6f}")
    print(f"X        : {X_opt:.6f}")
    print(f"L1 error : {final_l1:.6f}")

    plt.figure(figsize=(7, 6))
    plt.scatter(x_obs, y_obs, s=18, label="CSV points")
    plt.plot(x_pred, y_pred, linewidth=2.0, label="Fitted curve")
    plt.axis("equal")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig("output_plot.png", dpi=200)

    theta_str = f"{theta_opt:.6f}°"
    M_str = f"{M_opt:.6f}"
    X_str = f"{X_opt:.6f}"

    print("\nEquation (copy-friendly):")
    print(
        "x(t) = t*cos(" + theta_str + ") - exp(" + M_str + "*|t|)*sin(0.3*t)*sin(" + theta_str + ") + " + X_str
    )
    print(
        "y(t) = 42 + t*sin(" + theta_str + ") + exp(" + M_str + "*|t|)*sin(0.3*t)*cos(" + theta_str + ")"
    )

    plt.figure(figsize=(7, 6))
    plt.plot(t, x_obs, "o", markersize=3, label="x data")
    plt.plot(t, x_pred, "-", linewidth=2, label="x fitted")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig("estimated_curve.png", dpi=200)


if __name__ == "__main__":
    main()

