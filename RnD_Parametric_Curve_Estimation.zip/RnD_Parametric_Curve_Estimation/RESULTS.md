## Estimated Parameters

These values were produced by running:

- `python solution.py`

## Note on the reported L1 error
The assignment’s model uses parameter values across a time interval **t ∈ [6, 60]**.
Since the CSV (`xy_data.csv`) does not include explicit `t` values, the script assumes the CSV rows correspond to a **uniform sampling of t** across [6, 60].
So the reported **L1 error** reflects the fit under that ordering/sampling assumption.

- θ (deg): 28.220433
- M: 0.021535
- X: 54.906965
- L1 error: 37865.363941

